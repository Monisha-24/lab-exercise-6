/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class interface prgm
{
	public static void main(String[] args) {
	    Scanner val=new Scanner (System .in);
	    customer c[]=new employee[10];
		System.out.println("Enter the no of records to be displayed:");
		int size=gal.nextInt();
		for(int i=0;i<size;i++)
		{
		    c[i]=new employee();
		    System .out.println("\n======\center details of employee");
		    c[i].information ();
		}
		System .out.println ("Display employee details:");
		for(int i=0;i<size ;i++)
		{
		    System .out .println("\n======\nEmployee"+(i+1));
		    c[i].show();
;

		}
	}
	interface customer 
	{
	    float tax1=0.0F,tax2=0.1F,tax3=0.2F,tax4=0.25F;
	    void information ();
	    void show();
	    Scanner val=new Scanner (System .in);
	}
	class employee implements customer 
{
    String name,I'd,gender;
    long income ;
    
    public void information ()
    {
        System .out.println("Enter name:");
        name =val.next();
        system .out.println ("enter id":);
        id=val.next ();
        System .out.println("enter gender:");
        gender =gal.next();
        System .out.println("Enter income");
        income =gal.nextlong();
    }
    
    public void show()
    {
        System .out.println("NAME:"name+"\nID:"+id+"\n GENDER :"+gender+\nIncome:Rs."+income););
        if(income<=190000&&(gender .equals("Male")||gender .equals("Female")))
        {
            System .out.println("Tax percentage :"+tax1+"%");
            System .out.println("Tax of the employee :Nil");
            System .out.println ("Income after deducting tax:Rs:"×income+"/-");
        }
        elseif (income>190000&&income <20000)
        {
            if(gender .equals("Male"))
            {
                System .out.println("Tax percentage :"+(tax2*100)+"%");
                System .out.println("Tax of employee:Rs."+(income*tax2)+"/-");
                System .out.println("Income after deductivity tax:Rs."+(income -(income tax2))+"/-");
            }
            else
            {
                System .out.println("Tax percentage :"+tax1+"%");
                System .out.println("Tax of employee:Nil");
                System .out.println ("Income after deducting tax:Rs."×income+"/-");
            }
        }
        elseif(income >=200000&&income<500000)
        {
            if(gender.equals("Male"))
            {
                System .out.println("Tax percentage :"+(tax4*100)+"%");
                System .out.println("Tax of the employee:Rs."+(income *tax4)"/");
                System .out.println("Income after deducting tax:Rs"+(income-(income*tax4)+"/-");
            }
            elseif
            {
                System .out.println("Tax percentage :"+(tax3*100)+"%");
                System .out.println("Tax of the emplee:Rs."+(income*tax3)+"\-");"
                System .out.println("Income after deducting tax:Re."+(income-(income*tax3))+"/-");
            
            }
            else
            {
                if(gender.equals("male"))
                {
                    System .out.println("Tax percentage :"+(tax3*100)+"%");
                    System .out.println("Tax of the employees:Rs."+(income*tax3)×"/-");
                    
                    System .out.println("Income after deducting tax:Rs."+(income-(income*tax3))+"/-");
                    
                }
            }
            else 
            {
                System.out.println("tax percentage:"+(tax2*100)+"%");
                System.of.println("Tax of tge employee:Rs."+(income*tax2)+"/-");
            System.out.println("income after deducting tax:Rs."+(income-(income*tax2))+"/-");
            }
        }
    }
}
}
